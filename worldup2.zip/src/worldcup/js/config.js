var osType =1; // 0->android , 1->tizen
var developMode = 0//baraye build geteftan beshe 0
var api_url = "https://sambazar.tvapps.ir/api/v2";
var FileName = "online_chat_tk";
var socketUrl = "wss://metadata.tvapps.ir";
var TVChannel = "Apps";

export  const  ROAST_CONFIG = {
    OS_TYPE: osType,
    DEVELOP_MODE: developMode,
    API_URL: api_url,
    FILE_NAME :FileName,
    SOCKET_URL:socketUrl,
    TV_CHANNEL:TVChannel
}
